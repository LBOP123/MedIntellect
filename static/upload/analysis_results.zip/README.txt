分析结果包说明
==================

本压缩包包含以下分析结果：

1. text_analysis/ - 文本分析结果
   - original_document.txt: 原始文档内容
   - keywords.txt: 提取的关键词
   - pos_tagging.txt: 词性标注结果
   - named_entities.txt: 命名实体识别结果
   - summary.txt: 文档摘要
   - analysis_report.txt: 分析报告

2. clustering_analysis/ - 聚类分析结果
   - clustering_report.txt: 聚类分析报告
   - detailed_results.txt: 详细聚类结果
   - tsne_coordinates.json: t-SNE降维坐标数据
   - tsne_visualization.png: t-SNE可视化图像
   - wordcloud.png: 词云图

生成时间: 2025-06-01 21:32:36

使用说明：
- 所有文本文件使用UTF-8编码
- JSON文件可以用于进一步的数据分析
- PNG图像文件可以直接查看或用于报告
